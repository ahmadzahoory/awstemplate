<?php

require __DIR__ . '/../src/app.php';
